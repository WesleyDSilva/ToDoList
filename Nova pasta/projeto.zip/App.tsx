import React, {useState} from 'react';
import {
  View,
  StyleSheet,
  Alert,
} from 'react-native';
import TodoList from './comp/TodoList';
import AddTodo  from './comp/AddTodo';
import { Todo } from './comp/Todo';

const App: React.FC = () => {


  const [tarefas, setTodos] = useState<Todo[]>([]);

  const adicionaTarefa = (todoText: string) => {

    if(todoText.length > 0)
    {
      setTodos([...tarefas, {id: Date.now().toString(), text: todoText}]);
    } else {

      Alert.alert(
        "Erro", 
        "Preencha um valor na tarefa", 
        [
          {
            text: "OK"
          }
        ]
      );
    }
  }

  const removerTarefa = (idTarefa: string) => {
      setTodos([...tarefas.filter(tarefa => tarefa.id !== idTarefa)]);
  }

  return (    
  
    <View>
      <AddTodo onAddTodo = {adicionaTarefa} />

      <TodoList todos={tarefas} onRemoveTodo={removerTarefa} />
    </View>
  )
};

export default App;
